# GUNDAM Launcher

A simple Android HOME launcher with a futuristic black / cyan / red interface, digital clock, tactical shortcuts, and a grid of installed apps.

## Build in Android Studio

1. Extract this ZIP.
2. Open the `GundamLauncher` folder in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK components (compile SDK 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the APK on your Android phone.
6. Press Home and choose **GUNDAM Launcher**. To make it the default, select **Always**.

## Notes

- This project uses native Kotlin and Android views; no external libraries are required.
- The launcher includes a dark sci-fi interface inspired by the supplied Gundam wallpaper, but does not automatically set the wallpaper. Set the image as your phone wallpaper through the phone's wallpaper settings.
- Android 11+ limits visibility of installed apps. This sample requests package visibility for launcher apps; review the permission declaration and adapt it if publishing to Google Play.
- Tested structure targets Android API 35 and requires a compatible Android Studio / Gradle installation.
