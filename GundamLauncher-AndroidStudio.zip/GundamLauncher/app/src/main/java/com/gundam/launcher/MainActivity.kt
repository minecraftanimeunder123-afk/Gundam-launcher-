package com.gundam.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val cyan = Color.rgb(0, 190, 255)
    private val red = Color.rgb(255, 45, 65)
    private val white = Color.WHITE
    private val bg = Color.rgb(3, 8, 22)
    private lateinit var clock: TextView
    private lateinit var dateText: TextView
    private lateinit var appGrid: GridLayout
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildHome()
        updateClock()
        root.post(object : Runnable {
            override fun run() {
                updateClock()
                root.postDelayed(this, 30_000)
            }
        })
    }

    private fun buildHome() {
        root = FrameLayout(this)
        root.setBackgroundColor(bg)
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "GUNDAM // SYSTEM"
            textSize = 13f
            letterSpacing = 0.18f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(34), 1f))
        val status = TextView(this).apply {
            text = "● ONLINE"
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(90, 255, 190))
        }
        top.addView(status)
        content.addView(top)

        val line = View(this).apply { background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cyan, red, Color.TRANSPARENT)
        ) }
        content.addView(line, LinearLayout.LayoutParams(-1, dp(2)))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = panelDrawable()
            setPadding(dp(16), dp(20), dp(16), dp(18))
        }
        val emblem = TextView(this).apply {
            text = "✦"
            textSize = 42f
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        hero.addView(emblem)
        clock = TextView(this).apply {
            text = "--:--"
            textSize = 48f
            gravity = Gravity.CENTER
            setTextColor(white)
            letterSpacing = 0.08f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        hero.addView(clock)
        dateText = TextView(this).apply {
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            letterSpacing = 0.14f
        }
        hero.addView(dateText)
        val slogan = TextView(this).apply {
            text = "MOBILE SUIT  •  READY FOR DEPLOYMENT"
            textSize = 9f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            letterSpacing = 0.12f
            setPadding(0, dp(12), 0, 0)
        }
        hero.addView(slogan)
        val heroParams = LinearLayout.LayoutParams(-1, -2)
        heroParams.setMargins(0, dp(20), 0, dp(18))
        content.addView(hero, heroParams)

        val section = TextView(this).apply {
            text = "TACTICAL SHORTCUTS"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(section)
        val shortcuts = GridLayout(this).apply {
            columnCount = 3
            rowCount = 2
            setPadding(0, dp(12), 0, dp(18))
        }
        addShortcut(shortcuts, "PHONE", "☎", cyan) { launchIntent(Intent(Intent.ACTION_DIAL)) }
        addShortcut(shortcuts, "MESSAGES", "✉", red) { launchIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)) }
        addShortcut(shortcuts, "CAMERA", "◎", cyan) { launchIntent(Intent("android.media.action.IMAGE_CAPTURE")) }
        addShortcut(shortcuts, "BROWSER", "◉", red) { launchIntent(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))) }
        addShortcut(shortcuts, "SETTINGS", "⚙", cyan) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        addShortcut(shortcuts, "WALLPAPER", "▧", red) { openWallpaperSettings() }
        content.addView(shortcuts)

        val appsTitle = TextView(this).apply {
            text = "ALL SYSTEMS"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(appsTitle)
        val hint = TextView(this).apply {
            text = "Tap an app icon to launch it"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(8))
        }
        content.addView(hint)
        appGrid = GridLayout(this).apply { columnCount = 4 }
        content.addView(appGrid)
        populateApps()

        val footer = TextView(this).apply {
            text = "GUNDAM  •  UNIVERSAL CENTURY INTERFACE"
            textSize = 9f
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(20), 0, 0)
        }
        content.addView(footer)
    }

    private fun addShortcut(grid: GridLayout, label: String, glyph: String, accent: Int, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = panelDrawable()
            setPadding(dp(4), dp(12), dp(4), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val icon = TextView(this).apply {
            text = glyph
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(accent)
        }
        card.addView(icon)
        val text = TextView(this).apply {
            this.text = label
            textSize = 9f
            gravity = Gravity.CENTER
            setTextColor(white)
            letterSpacing = 0.05f
            setPadding(0, dp(5), 0, 0)
        }
        card.addView(text)
        val params = GridLayout.LayoutParams().apply {
            width = 0
            height = dp(86)
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        grid.addView(card, params)
    }

    private fun populateApps() {
        appGrid.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
        for (resolve in apps) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(8), dp(3), dp(8))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(resolve.activityInfo.packageName)
                    if (launch != null) launchIntent(launch)
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(resolve.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val name = TextView(this).apply {
                text = resolve.loadLabel(packageManager).toString()
                textSize = 9f
                gravity = Gravity.CENTER
                setTextColor(white)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            }
            item.addView(name, LinearLayout.LayoutParams(-1, -2))
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(82)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            appGrid.addView(item, params)
        }
    }

    private fun updateClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        dateText.text = SimpleDateFormat("EEEE  •  dd MMMM yyyy", Locale.getDefault()).format(now).uppercase(Locale.getDefault())
    }

    private fun panelDrawable(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(8, 18, 38))
        setStroke(dp(1), Color.rgb(0, 90, 145))
        cornerRadius = dp(10).toFloat()
    }

    private fun launchIntent(intent: Intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "No compatible app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openWallpaperSettings() {
        try {
            startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
